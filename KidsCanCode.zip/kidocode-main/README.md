# <p align="center"><img src="./images/kidocode-logo.svg" height="52"/></p><p align="center"><sup>Educational Coding Game for Kids</sup><p>
<p align="center"><img src="./images/kidocode-thumbnail.png" width="80%"/></p>
<h3>About</h3>
<p>KidoCode is a user-friendly, web-based educational game that provides a basic understanding of programming logic through interactive code blocks.</p>
<code>modern-web-tech</code>
<code>html5-apis</code>
<code>vanila-js</code>
<code>dom-manipulations</code>
<code>canvas</code>
<code>css3-features</code>
<code>local-storage</code>
